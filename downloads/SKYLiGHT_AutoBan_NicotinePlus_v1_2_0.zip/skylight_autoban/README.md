# SKYLiGHT Auto-Ban plugin

Unofficial Nicotine+ plugin v1.2.0.

Install this folder into your Nicotine+ plugins directory. See the repository root README for detailed installation instructions, settings, troubleshooting, privacy notes, and limitations.

The plugin inspects descriptions only after users appear in matching search results and return profile information. Defaults match `SKYLiGHT` and `skylight.beer` case-insensitively and use `DASH` as the search-result path marker.

License: Apache-2.0; see the repository root `LICENSE`.
